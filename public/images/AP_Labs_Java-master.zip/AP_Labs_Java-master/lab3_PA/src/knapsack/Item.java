package knapsack;

public interface Item {
    float profitFactor();
    int getValue();
    int getWeight();
    String getName();
}
