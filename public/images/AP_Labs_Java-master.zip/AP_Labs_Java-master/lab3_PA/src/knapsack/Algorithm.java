package knapsack;

import java.util.List;

public interface Algorithm {
    List<Item> getSolution();
}
