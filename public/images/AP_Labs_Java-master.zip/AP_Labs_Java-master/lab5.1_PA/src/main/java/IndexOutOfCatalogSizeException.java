public class IndexOutOfCatalogSizeException extends Exception {
    public IndexOutOfCatalogSizeException(String message) {
        super(message);
    }
}
