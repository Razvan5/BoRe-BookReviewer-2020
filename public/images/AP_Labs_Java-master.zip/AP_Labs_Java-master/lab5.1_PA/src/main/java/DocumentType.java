public enum DocumentType {
    INTERNAL,
    EXTERNAL
}
