package server;

public class Player {
    private int turn;


}
