package client;

import server.Board;

public class Game {
    private int id;
    private Board board;
}
