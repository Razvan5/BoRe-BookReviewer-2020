package Optional;

public enum VehicleType {
    CAR,
    TRUCK,
    DRONE;
}
