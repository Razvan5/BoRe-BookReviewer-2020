package Mandatory;

public enum VehicleColor {
    RED,
    BLUE,
    GREEN,
    YELLOW,
    BLACK,
    PURPLE,
    CYAN,
    MAGENTA,
    WHITE,
    GREY,
    DARKGREY;
}
