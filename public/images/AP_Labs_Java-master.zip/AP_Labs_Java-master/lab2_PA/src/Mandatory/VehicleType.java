package Mandatory;

public enum VehicleType {
    CAR,
    TRUCK,
    DRONE;
}
