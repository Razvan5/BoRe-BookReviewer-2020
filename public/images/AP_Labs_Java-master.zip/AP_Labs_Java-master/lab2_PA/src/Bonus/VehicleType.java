package Bonus;

public enum VehicleType {
    CAR,
    TRUCK,
    DRONE;
}
