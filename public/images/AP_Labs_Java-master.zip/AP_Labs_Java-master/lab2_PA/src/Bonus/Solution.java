package Bonus;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Solution {

    private List<Tour> listOfTours = new ArrayList<>();
    private boolean isSolutionViable;

    public Solution(Problem problem){
        List<Client> tempClients = problem.getListOfClients();
        List<Depot> tempListOfDepots = problem.getListOfDepots();



    }



    public List<Tour> getListOfTours() {
        return listOfTours;
    }
}
